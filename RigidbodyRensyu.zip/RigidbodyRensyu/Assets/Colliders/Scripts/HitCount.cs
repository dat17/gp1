﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HitCount : MonoBehaviour {

	public Text hitText;
	private int hitCount = 0;

	void OnTriggerEnter2D(Collider2D col) {
		hitCount++;
		hitText.text = "Hit: "+hitCount;
	}
}
