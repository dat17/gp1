﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mover : MonoBehaviour {
	public Vector2 movement = new Vector2(-5f, 0f);

	// Use this for initialization
	void Start () {
		GetComponent<Rigidbody2D> ().velocity = movement;
	}
}
