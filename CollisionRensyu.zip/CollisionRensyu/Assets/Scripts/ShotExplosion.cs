﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotExplosion : MonoBehaviour {

	public GameObject prefExplosion;
    public float LIFE_DURATION = 3f;

    private void Awake()
    {
        Destroy(gameObject, LIFE_DURATION);
    }

    void OnCollisionEnter(Collision col) {
		SoundPlayer.PlaySE (SoundPlayer.SE.EXPLOSION);
		Instantiate (prefExplosion, transform.position, Quaternion.identity);
		Destroy (gameObject);
	}

}
