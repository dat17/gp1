﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundPlayer : MonoBehaviour {
	private static SoundPlayer instance;

	public AudioClip [] clips;
	public enum SE {
		SHOT, 
		EXPLOSION
	}

	private AudioSource source;

	// Use this for initialization
	void Awake () {
		instance = this;
		source = GetComponent<AudioSource> ();
	}

	public static void PlaySE(SE se) {
		instance._playSE (se);
	}

	protected void _playSE(SE se) {
		source.PlayOneShot (clips [(int)se]);
	}
}
