﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	public Vector3 rotateVelocity = new Vector3 (0f, 120f, 0f);
	public GameObject prefShot;
    public float Speed = 10f;
    public float RANDOM_DIR = 10f;

    // Update is called once per frame
    void Update () {
		transform.Rotate (rotateVelocity*Time.deltaTime, Space.World);

		if (Input.GetMouseButtonDown (0)) {
			SoundPlayer.PlaySE (SoundPlayer.SE.SHOT);
			GameObject go = Instantiate (prefShot, transform.position, Quaternion.identity);
            go.GetComponent<Rigidbody>().velocity = Quaternion.Euler(Vector3.forward * Random.Range(-RANDOM_DIR, RANDOM_DIR)) * Vector3.right * Speed;
        }
    }
}
